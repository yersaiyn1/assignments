abstract class Message {
    public abstract void send();
}
