import java.util.ArrayList;
import java.util.List;

// Observer Interface
interface Observer {
    void update(String message);
}